/* Shakespeare's Plays

In this project we will be practicing selecting DOM elements and manipulating them using JavaScript.

- Here are the steps you will need to follow:
	- Download the starter code.
	- Add a class of `special` to all of the `<li>` elements at the second level of the nested list.
	- Add a class of `year` to all of the table cells in the third column of a table.
		- Hint: Take a look at how many columns are in each table.
	- Make every other table row in both tables have a gray background.
	- Select an anchor tag that has a link to a pdf file. Change the color to blue and increase the font size.
	- Select an anchor tag that has an href attribute containing the substring "asyoulikeit" and change the font color to orange.

*/

//Add a class of `special` to all of the `<li>` elements at the second level of the nested list.
var li = document.querySelectorAll("ul ul li, ul ul li a");
for (var i = 0; i < li.length; i++) {
	li[i].classList.add("special");
}

//Add a class of `year` to all of the table cells in the third column of a table.
var td = document.querySelectorAll("tr td+td+td");
for (var i = 0; i < td.length; i++) {
	td[i].classList.add("year");
}

//Make every other table row in both tables have a gray background.
var oddRows = document.querySelectorAll("tr:nth-child(odd");
for (var i = 0; i < oddRows.length; i++) {
	oddRows[i].setAttribute("style", "background-color: #ccc;");
}

//Select an anchor tag that has a link to a pdf file. Change the color to blue and increase the font size.
var links = document.getElementsByTagName("a");
for (var i = 0; i < links.length; i++) {
	if (/.pdf$/.test(links[i].href)) {
		links[i].setAttribute("style", "color: #3967FF;font-size:1.4em;");
	}
}

//Select an anchor tag that has an href attribute containing the substring "asyoulikeit" and change the font color to orange.
for (var i = 0; i < links.length; i++) {
	if (/asyoulikeit/i.test(links[i].href)) { 
		links[i].setAttribute("style", "color: #FFA500;");
	}
}